package com.todolist.staff;

import com.todolist.dto.StaffDto;
import com.todolist.entity.Staff;
import com.todolist.entity.Task;
import com.todolist.entity.ToDoList;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.WebUtils;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class StaffService {
    @Autowired
    private StaffRepository staffRepository;


    public Staff login(Staff staff) {
        //Assume no password validation
        return staffRepository.findByEmail(staff.getEmail());
    }

    public Staff get(Integer id){
        Optional<Staff> staff = staffRepository.findById(id);
        return staff.isPresent()? staff.get() : null;
    }

    public StaffDto getDto(Integer id){
        Optional<Staff> staff = staffRepository.findById(id);

        return staff.isPresent()? this.convertDataIntoDTO(staff.get()) : null;
    }

    public Staff get(String idString){
        return this.get(Integer.parseInt(idString));
    }


    public List<Staff> getAllStaff() {
        return (List<Staff>) staffRepository.findAll();
    }

    public Staff save(Staff staff){
        return staffRepository.save(staff);
    }

    public Staff getStaffFromCookie(HttpServletRequest request){
        Cookie staffIdCookie = WebUtils.getCookie(request, "staffId");
        if (staffIdCookie == null){
            return null;
        }
        Staff staff = get(staffIdCookie.getValue());
        return staff;
    }

    public StaffDto getStaffDtoFromCookie(HttpServletRequest request){
        Cookie staffIdCookie = WebUtils.getCookie(request, "staffId");
        if (staffIdCookie == null){
            return null;
        }
        StaffDto dto = convertDataIntoDTO(get(staffIdCookie.getValue()));
        return dto;
    }

    private static StaffDto convertDataIntoDTO (Staff staffData) {

        StaffDto dto = new StaffDto();

        dto.setAdmin(staffData.isAdmin());
        dto.setEnabled(staffData.isEnabled());

        dto.setEmail(staffData.getEmail());
        dto.setId(staffData.getId());
        dto.setPassword(staffData.getPassword());
        dto.setName(staffData.getName());
        dto.setTaskSet(staffData.getTaskSet().stream().map(Task::getId).collect(Collectors.toSet()));
        dto.setToDoListSet(staffData.getToDoListSet().stream().map(ToDoList::getId).collect(Collectors.toSet()));

        return dto;
    }

}
