package com.todolist.task;

import com.todolist.dto.StaffDto;
import com.todolist.dto.TaskDto;
import com.todolist.entity.Staff;
import com.todolist.entity.Task;
import com.todolist.entity.ToDoList;
import com.todolist.staff.StaffService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private StaffService staffService;

    public Task get(Integer id){
        Optional<Task> optionalTask = taskRepository.findById(id);
        return optionalTask.isPresent()? optionalTask.get(): null;
    }

    public Task get(String id){
        return this.get(Integer.parseInt(id));
    }

    public TaskDto getDto(Integer id){
        return convertDataIntoDTO(get(id));
    }

    public List<Task> getAllTasks(){
        return (List<Task>) taskRepository.findAll();
    }

    public List<Task> getTasksByStaffId(int staffId){
        Staff staff = staffService.get(staffId);
        if(staff == null) return new ArrayList<>();
        return new ArrayList<>(staff.getTaskSet());
    }

    public List<TaskDto> getTaskDtosByStaffId(int staffId){
        StaffDto staff = staffService.getDto(staffId);
        if(staff == null) return new ArrayList<>();
        List<TaskDto> dtoList = staff.getTaskSet().stream().map(id -> getDto(id)).toList();
        return dtoList;
    }

    public void save(Task task, String staffId) {

        String [] staffIdList = staffId.split(",");
        for (String idString : staffIdList){
            if(!idString.isBlank()){
                int id = Integer.parseInt(idString);
                Staff s = staffService.get(id);
                task.getStaffSet().add(s);
                s.getTaskSet().add(task);
                staffService.save(s);
            }
        }
        taskRepository.save(task);

    }

    public Task deleteById(int id){
        Optional<Task> taskOptional = taskRepository.findById(id);

        if(taskOptional.isPresent()){
            Task task = taskOptional.get();
            task.removeAllStaffPic();
            taskRepository.deleteById(id);
            return task;
        }

        return null;

    }


    private static TaskDto convertDataIntoDTO (Task taskData) {

        TaskDto dto = new TaskDto();

        dto.setId(taskData.getId());
        dto.setTitle(taskData.getTitle());
        dto.setDescription(taskData.getDescription());
        dto.setStatus(taskData.getStatus());
        dto.setStaffSet(taskData.getStaffSet().stream().map(Staff::getId).collect(Collectors.toSet()));

        return dto;
    }

}
