package com.todolist.dto;

import com.todolist.entity.Task;
import com.todolist.entity.ToDoList;
import jakarta.persistence.Column;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class StaffDto {
    private Integer id;
    private String email;
    private String password;
    private String name;
    private boolean enabled;
    private boolean isAdmin;
    private Set<Integer> taskSet = new HashSet<>();
    private Set<Integer> toDoListSet = new HashSet<>();
}
