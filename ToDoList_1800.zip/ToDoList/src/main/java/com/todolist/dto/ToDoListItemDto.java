package com.todolist.dto;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class ToDoListItemDto {
    private Integer id;
    private String type;
    private String data;
    private String status;

}
