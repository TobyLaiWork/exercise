package com.todolist.dto;


import com.todolist.entity.Staff;
import com.todolist.entity.Task;
import jakarta.persistence.*;
import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class TaskDto {
    private Integer id;
    private String title;
    private String description;
    private String status;
    private Set<Integer> staffSet = new HashSet<>();
}
