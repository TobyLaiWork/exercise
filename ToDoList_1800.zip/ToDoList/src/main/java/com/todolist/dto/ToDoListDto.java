package com.todolist.dto;

import com.todolist.entity.Staff;
import com.todolist.entity.Task;
import com.todolist.entity.ToDoListItem;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

import java.util.HashSet;
import java.util.Set;

@Data
public class ToDoListDto {
    private Integer id;
    private Task task;
    private String title;
    private String description;
    private Staff staff;
    private Set<ToDoListItem> toDoListItemSet = new HashSet<>();

}
