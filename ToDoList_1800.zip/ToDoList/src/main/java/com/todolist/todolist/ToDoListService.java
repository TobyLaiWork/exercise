package com.todolist.todolist;

import com.todolist.entity.Staff;
import com.todolist.entity.Task;
import com.todolist.entity.ToDoList;
import com.todolist.entity.ToDoListItem;
import com.todolist.staff.StaffService;
import com.todolist.task.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ToDoListService {

    @Autowired
    private ToDoListRepository toDoListRepository;

    @Autowired
    private ToDoListItemRepository toDoListItemRepository;

    @Autowired
    private StaffService staffService;

    @Autowired
    private TaskService taskService;

    public ToDoList get(Integer id){
        return toDoListRepository.findById(id).get();
    }

    public ToDoList get(String id){
        return this.get(Integer.parseInt(id));
    }

    public ToDoListItem getItem(String id) {
        return this.getItem(Integer.parseInt(id));
    }

    public ToDoListItem getItem(Integer id){
        return toDoListItemRepository.findById(id).get();
    }


    public List<ToDoList> getAllToDoLists(){
        return (List<ToDoList>) toDoListRepository.findAll();
    }

    public List<ToDoList> getToDoListsByStaffId(int staffId){
        Staff staff = staffService.get(staffId);
        if(staff == null) return new ArrayList<>();
        return new ArrayList<>(staff.getToDoListSet());
    }

    public void save(ToDoList toDoList) {
        toDoListRepository.save(toDoList);
    }

    public void saveItem(ToDoListItem toDoListItem) {
        toDoListItemRepository.save(toDoListItem);
    }

    public void save(ToDoList toDoList, String staffId, String taskId) {
        Staff staff = staffService.get(staffId);
        if(taskId != null && !taskId.isBlank()){
            Task task = taskService.get(taskId);
            toDoList.setTask(task);
        }
        toDoList.setStaff(staff);

        toDoListRepository.save(toDoList);
    }

    public ToDoList deleteById(Integer id) {
        Optional<ToDoList> toDoListOptional = toDoListRepository.findById(id);
        if(toDoListOptional.isPresent()){
            ToDoList toDoList = toDoListOptional.get();
            toDoList.removeAllItem();
            toDoListRepository.deleteById(id);
            return toDoList;
        }
        return null;
    }

    public ToDoListItem deleteItemById(Integer id) {
        Optional<ToDoListItem> toDoListItemOptional = toDoListItemRepository.findById(id);
        if(toDoListItemOptional.isPresent()){
            ToDoListItem toDoListItem = toDoListItemOptional.get();
            toDoListItemRepository.deleteById(id);
            return toDoListItem;
        }
        return null;
    }



}
