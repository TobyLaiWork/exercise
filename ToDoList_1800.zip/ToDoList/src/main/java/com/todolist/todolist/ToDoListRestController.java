package com.todolist.todolist;

import com.todolist.entity.ToDoList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ToDoListRestController {
    @Autowired
    private ToDoListService toDoListService;

    @GetMapping("/todolistByStaff/{id}")
    List<ToDoList> getToDoListByStaff(@PathVariable int id) {
        List<ToDoList> toDoListList = toDoListService.getToDoListsByStaffId(id);
        return toDoListList;
    }

    @PostMapping("/createToDoList")
    void createToDoList(@RequestBody ToDoList toDoList) {
        toDoListService.save(toDoList);
    }

}
