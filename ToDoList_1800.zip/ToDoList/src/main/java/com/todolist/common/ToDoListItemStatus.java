package com.todolist.common;

public enum ToDoListItemStatus {
    ONGOING("Ongoing"),
    COMPLETED("Completed"),
    NA("N/A");

    private final String text;

    ToDoListItemStatus(final String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return text;
    }

}
