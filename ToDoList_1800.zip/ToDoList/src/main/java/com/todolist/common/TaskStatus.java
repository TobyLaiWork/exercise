package com.todolist.common;

public enum TaskStatus  {
    NEW("New"),
    ASSIGNED("Assigned"),
    COMPLETED("Completed");

    private final String text;

    TaskStatus(final String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return text;
    }

};