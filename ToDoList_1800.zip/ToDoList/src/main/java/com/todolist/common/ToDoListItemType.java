package com.todolist.common;



public enum ToDoListItemType  {
    ITEM("Item"),
    DESC("Description");

    private final String text;

    ToDoListItemType(final String text){
        this.text = text;
    }

    @Override
    public String toString(){
        return text;
    }

};